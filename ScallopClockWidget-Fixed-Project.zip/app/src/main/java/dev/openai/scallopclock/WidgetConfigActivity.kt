package dev.openai.scallopclock

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class WidgetConfigActivity : Activity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var selectedColor = Color.rgb(222, 213, 245)
    private var opacity = 100
    private var dynamic = true
    private val swatches = intArrayOf(
        Color.rgb(222,213,245), Color.rgb(208,232,220), Color.rgb(255,224,204),
        Color.rgb(205,225,255), Color.rgb(255,214,225), Color.rgb(238,238,238),
        Color.rgb(40,40,48), Color.rgb(255,255,255)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        val prefs = getSharedPreferences(ClockWidgetProvider.PREFS, MODE_PRIVATE)
        selectedColor = prefs.getInt("color_$widgetId", selectedColor)
        opacity = prefs.getInt("opacity_$widgetId", 100)
        dynamic = prefs.getBoolean("dynamic_$widgetId", true)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(22), dp(24), dp(20))
            setBackgroundColor(Color.rgb(250,248,255))
        }
        root.addView(TextView(this).apply {
            text = "Scallop Clock settings"
            textSize = 23f
            setTextColor(Color.rgb(42,36,55))
        }, match(WRAP, dp(42)))
        root.addView(TextView(this).apply {
            text = "Background color"
            textSize = 16f
            setTextColor(Color.rgb(42,36,55))
        }, match(WRAP, dp(38)))

        val colors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        swatches.forEach { color ->
            val b = Button(this).apply {
                text = "●"
                textSize = 18f
                setTextColor(color)
                minWidth = dp(36); minimumWidth = dp(36)
                setPadding(0,0,0,0)
                setOnClickListener { selectedColor = color; dynamic = false; updateSwatchLabel() }
            }
            colors.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(colors, match(MATCH, dp(54)))
        val colorLabel = TextView(this).apply { textSize = 13f; setTextColor(Color.DKGRAY) }
        root.addView(colorLabel, match(WRAP, dp(28)))
        fun refreshLabel() { colorLabel.text = if (dynamic) "Color: Material You system accent" else "Selected color: #%06X".format(0xFFFFFF and selectedColor) }
        // Keep label reference updated by button interactions.
        colors.getChildCount().let { /* no-op */ }
        root.addView(TextView(this).apply {
            text = "Background opacity"
            textSize = 16f
            setTextColor(Color.rgb(42,36,55))
        }, match(WRAP, dp(38)))
        val opacityValue = TextView(this).apply { text = "$opacity%"; textSize = 14f; setTextColor(Color.DKGRAY) }
        root.addView(SeekBar(this).apply {
            max = 100; progress = opacity
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { opacity = progress; opacityValue.text = "$progress%" }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, match(MATCH, dp(40)))
        root.addView(opacityValue, match(WRAP, dp(28)))
        val dynamicSwitch = Switch(this).apply {
            text = "Material You auto coloring"
            textSize = 15f
            setTextColor(Color.rgb(42,36,55))
            isChecked = dynamic && Build.VERSION.SDK_INT >= 31
            isEnabled = Build.VERSION.SDK_INT >= 31
            setOnCheckedChangeListener { _, checked -> dynamic = checked; refreshLabel() }
        }
        root.addView(dynamicSwitch, match(MATCH, dp(48)))
        if (Build.VERSION.SDK_INT < 31) {
            root.addView(TextView(this).apply {
                text = "Automatic system coloring requires Android 12 or newer. Manual colors work on older versions."
                textSize = 12f
                setTextColor(Color.DKGRAY)
            }, match(WRAP, dp(48)))
        }
        val save = Button(this).apply {
            text = "Save widget"
            setOnClickListener {
                prefs.edit().putInt("color_$widgetId", selectedColor)
                    .putInt("opacity_$widgetId", opacity)
                    .putBoolean("dynamic_$widgetId", dynamic).apply()
                ClockWidgetProvider.updateWidget(this@WidgetConfigActivity, AppWidgetManager.getInstance(this@WidgetConfigActivity), widgetId)
                ClockWidgetProvider.scheduleNextMinute(this@WidgetConfigActivity)
                val result = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                setResult(RESULT_OK, result)
                finish()
            }
        }
        root.addView(save, match(MATCH, dp(54)))
        refreshLabel()
        setContentView(root)
    }

    private fun updateSwatchLabel() {
        // The chosen color is saved when Save is pressed; Material You can be toggled independently.
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun match(width: Int, height: Int) = LinearLayout.LayoutParams(if (width == MATCH) ViewGroup.LayoutParams.MATCH_PARENT else width, if (height == WRAP) ViewGroup.LayoutParams.WRAP_CONTENT else height)
    companion object { private const val MATCH = -1; private const val WRAP = -2 }
}
