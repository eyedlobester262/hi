package dev.openai.scallopclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.widget.RemoteViews
import java.util.Calendar

class ClockWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            try {
                updateWidget(context, manager, id)
            } catch (error: RuntimeException) {
                android.util.Log.e("ScallopClock", "Widget update failed for id=$id", error)
            }
        }
        try { scheduleNextMinute(context) }
        catch (error: RuntimeException) { android.util.Log.e("ScallopClock", "Could not schedule next tick", error) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TICK || intent.action == Intent.ACTION_TIME_CHANGED ||
            intent.action == Intent.ACTION_TIMEZONE_CHANGED || intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ClockWidgetProvider::class.java))
            ids.forEach { id ->
                try {
                    updateWidget(context, manager, id)
                } catch (error: RuntimeException) {
                    android.util.Log.e("ScallopClock", "Widget tick failed for id=$id", error)
                }
            }
            if (ids.isNotEmpty()) {
                try { scheduleNextMinute(context) }
                catch (error: RuntimeException) { android.util.Log.e("ScallopClock", "Could not schedule next tick", error) }
            }
        }
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        appWidgetIds.forEach { id -> prefs.remove("color_$id").remove("opacity_$id").remove("dynamic_$id") }
        prefs.apply()
        super.onDeleted(context, appWidgetIds)
    }

    companion object {
        const val PREFS = "scallop_widget_prefs"
        const val ACTION_TICK = "dev.openai.scallopclock.MINUTE_TICK"

        fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val views = RemoteViews(context.packageName, R.layout.widget_clock)
            val now = Calendar.getInstance()
            val hour = now.get(Calendar.HOUR)
            val minute = now.get(Calendar.MINUTE)
            views.setImageViewResource(R.id.clock_face, R.drawable.scallop_face)
            views.setInt(R.id.clock_face, "setColorFilter", resolveFaceColor(context, prefs, id))
            views.setFloat(R.id.hour_hand, "setRotation", (hour * 30f) + (minute / 2f))
            views.setFloat(R.id.minute_hand, "setRotation", minute * 6f)
            val ink = if (Build.VERSION.SDK_INT >= 31) systemColor(context, "system_accent1_700", Color.rgb(52,45,73)) else Color.rgb(52,45,73)
            views.setInt(R.id.hour_hand, "setColorFilter", ink)
            views.setInt(R.id.minute_hand, "setColorFilter", ink)
            views.setInt(R.id.center_dot, "setColorFilter", ink)
            val configIntent = Intent(context, WidgetConfigActivity::class.java).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            val pi = PendingIntent.getActivity(context, id, configIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_settings, pi)
            views.setOnClickPendingIntent(R.id.clock_face, pi)
            manager.updateAppWidget(id, views)
        }

        private fun resolveFaceColor(context: Context, prefs: android.content.SharedPreferences, id: Int): Int {
            val dynamic = prefs.getBoolean("dynamic_$id", true)
            val base = if (dynamic && Build.VERSION.SDK_INT >= 31) systemColor(context, "system_accent1_100", Color.rgb(222,213,245))
                       else prefs.getInt("color_$id", Color.rgb(222,213,245))
            val opacity = prefs.getInt("opacity_$id", 100).coerceIn(0,100)
            return Color.argb((opacity * 255 / 100), Color.red(base), Color.green(base), Color.blue(base))
        }

        private fun systemColor(context: Context, name: String, fallback: Int): Int {
            return try {
                val resId = context.resources.getIdentifier(name, "color", "android")
                if (resId != 0) context.getColor(resId) else fallback
            } catch (_: Exception) { fallback }
        }

        fun scheduleNextMinute(context: Context) {
            val intent = Intent(context, ClockWidgetProvider::class.java).setAction(ACTION_TICK)
            val pi = PendingIntent.getBroadcast(context, 9001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val next = System.currentTimeMillis() - (System.currentTimeMillis() % 60000L) + 60000L
            try {
                if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi)
                else alarm.setExact(AlarmManager.RTC, next, pi)
            } catch (_: SecurityException) {
                // Exact-alarm access can be restricted on some Android 12+ devices.
                // Fall back gracefully; updates may be less punctual under battery restrictions.
                if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
                else alarm.set(AlarmManager.RTC, next, pi)
            }
        }
    }
}
