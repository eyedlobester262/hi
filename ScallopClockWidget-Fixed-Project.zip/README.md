# Scallop Clock Widget

A native Kotlin Android home-screen widget featuring a scalloped analog clock face, Material You system-accent coloring on Android 12+, per-widget background color and opacity, and a small settings button.

## Build online with GitHub Actions

1. Create a new GitHub repository and upload the contents of this folder (keep the `.github` folder).
2. Open the repository's **Actions** tab.
3. Enable Actions if prompted, then run **Build Android APK** using **Run workflow**. Pushing to `main` also triggers a build.
4. Open the completed workflow run and download the `scallop-clock-debug-apk` artifact.
5. Unzip it and install `app-debug.apk` on your device.

The debug APK is signed with Android's debug key and is suitable for testing. For a distributable release, create your own release signing key and configure a release build.

## Add the widget

After installing, long-press the home screen, choose Widgets, and add **Scallop Clock**. The app intentionally has no launcher activity, so it does not appear as a normal app icon in the app drawer. The widget's small gear button opens its settings.

## Compatibility

- `minSdk 23` (Android 6.0+)
- APK includes Android bytecode and is architecture-independent, so it works on x86/x86_64 Android as well as ARM devices.
- Material You system accent colors are enabled on Android 12+; manual background colors and opacity are available on older Android versions too.

## Notes

- The widget is rendered using RemoteViews-compatible native Android layouts.
- The clock schedules minute ticks while at least one widget is installed.
- Android launchers vary in whether they expose a separate "Edit" action; the widget provider declares a configuration activity and the gear button is a reliable settings entry point.
