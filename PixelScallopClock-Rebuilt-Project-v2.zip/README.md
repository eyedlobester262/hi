# Pixel Scallop Clock (reconstructed)

Reconstructed from the supplied APK's image resources and observed widget behavior. This is not the original source project.

## Build on GitHub Actions
Upload this ZIP as `PixelScallopClock-Rebuilt-Project.zip` at the repository root, then place `.github/workflows/build-scallop-apk.yml` at that exact path. Run **Build Pixel Scallop Clock APK** from Actions and download the artifact.

The app uses the original APK's dial/hour/minute image assets and an Android `AnalogClock` view, with a rebuilt settings activity that persists per-widget preferences and updates the widget after save.

This is a reconstructed build; test on the target device before relying on it.
