plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.pixelscallopedclock"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.pixelscallopedclock"
        minSdk = 23
        targetSdk = 28
        versionCode = 3
        versionName = "2.2-rebuilt"
    }
}
