package com.pixelscallopedclock

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var chosenColor = Color.rgb(222, 213, 245)
    private var opacity = 100

    private val palette = intArrayOf(
        Color.rgb(222,213,245), Color.rgb(208,232,220), Color.rgb(255,224,204),
        Color.rgb(205,225,255), Color.rgb(255,214,225), Color.rgb(238,238,238),
        Color.rgb(40,40,48), Color.WHITE
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }

        val prefs = getSharedPreferences(PixelScallopWidgetProvider.PREFS, MODE_PRIVATE)
        chosenColor = prefs.getInt("color_$widgetId", chosenColor)
        opacity = prefs.getInt("opacity_$widgetId", 100)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            setBackgroundColor(Color.rgb(250, 248, 255))
        }
        root.addView(TextView(this).apply {
            text = "Scallop Clock settings"; textSize = 22f
            setTextColor(Color.rgb(42,36,55))
        }, lp(MATCH, dp(44)))

        root.addView(TextView(this).apply {
            text = "Widget background"; textSize = 16f
            setTextColor(Color.rgb(42,36,55))
        }, lp(MATCH, dp(32)))

        val swatches = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val selectedLabel = TextView(this).apply { textSize = 13f; setTextColor(Color.DKGRAY) }
        fun refreshLabel() { selectedLabel.text = "Selected: #%06X".format(0xFFFFFF and chosenColor) }

        palette.forEach { color ->
            swatches.addView(Button(this).apply {
                text = "●"
                textSize = 17f
                setTextColor(color)
                minWidth = dp(34)
                setPadding(0,0,0,0)
                setOnClickListener { chosenColor = color; refreshLabel() }
            }, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(swatches, lp(MATCH, dp(52)))
        root.addView(selectedLabel, lp(MATCH, dp(26)))
        refreshLabel()

        root.addView(TextView(this).apply {
            text = "Background opacity"; textSize = 16f
            setTextColor(Color.rgb(42,36,55))
        }, lp(MATCH, dp(32)))
        val opacityLabel = TextView(this).apply { text = "$opacity%"; setTextColor(Color.DKGRAY) }
        root.addView(SeekBar(this).apply {
            max = 100; progress = opacity
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    opacity = progress; opacityLabel.text = "$progress%"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, lp(MATCH, dp(40)))
        root.addView(opacityLabel, lp(MATCH, dp(24)))

        if (Build.VERSION.SDK_INT >= 31) {
            root.addView(Switch(this).apply {
                text = "Use Material You accent"
                isChecked = prefs.getBoolean("dynamic_$widgetId", false)
                setOnCheckedChangeListener { _, checked ->
                    prefs.edit().putBoolean("dynamic_$widgetId", checked).apply()
                }
            }, lp(MATCH, dp(48)))
        } else {
            root.addView(TextView(this).apply {
                text = "Material You coloring needs Android 12 or newer."
                textSize = 12f; setTextColor(Color.DKGRAY)
            }, lp(MATCH, dp(32)))
        }

        root.addView(Button(this).apply {
            text = "Save changes"
            setOnClickListener {
                val alpha = (opacity * 255 / 100).coerceIn(0,255)
                val finalColor = Color.argb(alpha, Color.red(chosenColor), Color.green(chosenColor), Color.blue(chosenColor))
                prefs.edit()
                    .putInt("color_$widgetId", chosenColor)
                    .putInt("opacity_$widgetId", opacity)
                    .putInt("background_$widgetId", finalColor)
                    .apply()
                PixelScallopWidgetProvider.updateWidget(
                    this@SettingsActivity,
                    AppWidgetManager.getInstance(this@SettingsActivity),
                    widgetId
                )
                setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                finish()
            }
        }, lp(MATCH, dp(52)))
        setContentView(root)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun lp(width: Int, height: Int) = LinearLayout.LayoutParams(
        if (width == MATCH) ViewGroup.LayoutParams.MATCH_PARENT else width,
        if (height == WRAP) ViewGroup.LayoutParams.WRAP_CONTENT else height
    )
    companion object { private const val MATCH = -1; private const val WRAP = -2 }
}
