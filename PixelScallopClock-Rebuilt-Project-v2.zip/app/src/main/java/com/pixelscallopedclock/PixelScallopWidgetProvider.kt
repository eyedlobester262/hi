package com.pixelscallopedclock

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.widget.RemoteViews

class PixelScallopWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_UPDATE) {
            val manager = AppWidgetManager.getInstance(context)
            manager.getAppWidgetIds(ComponentName(context, PixelScallopWidgetProvider::class.java))
                .forEach { updateWidget(context, manager, it) }
        }
    }

    companion object {
        const val PREFS = "pixel_scallop_settings"
        const val ACTION_UPDATE = "com.pixelscallopedclock.UPDATE_WIDGET"

        fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val views = RemoteViews(context.packageName, R.layout.widget_pixel_scallop)

            // Preserve the original APK's native AnalogClock + scalloped dial/hands.
            val color = prefs.getInt("background_$id", Color.TRANSPARENT)
            if (color != Color.TRANSPARENT) {
                views.setInt(R.id.widget_root, "setBackgroundColor", color)
            } else {
                views.setInt(R.id.widget_root, "setBackgroundColor", Color.TRANSPARENT)
            }

            val config = Intent(context, SettingsActivity::class.java)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            val pi = PendingIntent.getActivity(
                context, id, config,
                PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            )
            views.setOnClickPendingIntent(R.id.widget_settings, pi)
            views.setOnClickPendingIntent(R.id.analog_clock, pi)
            manager.updateAppWidget(id, views)
        }
    }
}
