# Pixel Scallop Clock v4 (reconstructed)

This version restores the Petal Bump Softness slider, applies the chosen color and opacity to the clock face itself, keeps the widget background transparent, and opens settings only from the gear button. It uses a generated scalloped dial with adjustable bumpiness and the supplied original hour/minute hand assets.

Upload `PixelScallopClock-Rebuilt-Project-v4.zip` to the repository root. Copy `.github/workflows/build-scallop-apk.yml` from this ZIP to the repository's `.github/workflows/build-scallop-apk.yml`, then run the workflow from Actions.

This is a reconstructed implementation and should be tested on the target Huawei Android 10 device.
