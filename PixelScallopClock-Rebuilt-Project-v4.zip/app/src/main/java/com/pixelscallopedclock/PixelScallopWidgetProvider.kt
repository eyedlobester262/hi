package com.pixelscallopedclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Build
import android.widget.RemoteViews
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.PI

class PixelScallopWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, manager, it) }
        scheduleNextMinute(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_UPDATE || intent.action == ACTION_MINUTE || intent.action == Intent.ACTION_TIME_TICK ||
            intent.action == Intent.ACTION_TIME_CHANGED || intent.action == Intent.ACTION_TIMEZONE_CHANGED) {
            val manager = AppWidgetManager.getInstance(context)
            manager.getAppWidgetIds(ComponentName(context, PixelScallopWidgetProvider::class.java))
                .forEach { updateWidget(context, manager, it) }
            scheduleNextMinute(context)
        }
    }

    override fun onDisabled(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(updatePendingIntent(context))
    }

    companion object {
        const val PREFS = "pixel_scallop_settings"
        const val ACTION_UPDATE = "com.pixelscallopedclock.UPDATE_WIDGET"
        private const val ACTION_MINUTE = "com.pixelscallopedclock.MINUTE_UPDATE"
        private const val SIZE = 512

        fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val color = prefs.getInt("color_$id", Color.rgb(222, 213, 245))
            val opacity = prefs.getInt("opacity_$id", 100)
            val bump = prefs.getInt("bump_$id", 50).coerceIn(0, 100)
            val dynamic = prefs.getBoolean("dynamic_$id", false)
            val faceColor = if (dynamic && Build.VERSION.SDK_INT >= 31) {
                val resId = context.resources.getIdentifier("system_accent1_100", "color", "android")
                if (resId != 0) context.getColor(resId) else color
            } else color
            val face = makeFace(faceColor, opacity, bump)
            val now = Calendar.getInstance()
            val minuteAngle = (now.get(Calendar.MINUTE) + now.get(Calendar.SECOND) / 60f) * 6f
            val hourAngle = ((now.get(Calendar.HOUR) % 12) + now.get(Calendar.MINUTE) / 60f) * 30f

            val views = RemoteViews(context.packageName, R.layout.widget_pixel_scallop)
            views.setImageViewBitmap(R.id.clock_face, face)
            views.setImageViewResource(R.id.hour_hand, R.drawable.scallop_hour)
            views.setImageViewResource(R.id.minute_hand, R.drawable.scallop_minute)
            views.setFloat(R.id.hour_hand, "setRotation", hourAngle)
            views.setFloat(R.id.minute_hand, "setRotation", minuteAngle)

            val config = Intent(context, SettingsActivity::class.java)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            val pi = PendingIntent.getActivity(
                context, id, config,
                PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            )
            // Only the dedicated gear opens settings. Tapping the clock itself does nothing.
            views.setOnClickPendingIntent(R.id.widget_settings, pi)
            manager.updateAppWidget(id, views)
        }

        private fun makeFace(color: Int, opacity: Int, bump: Int): Bitmap {
            val bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val cx = SIZE / 2f
            val cy = SIZE / 2f
            val base = SIZE * 0.455f
            val amplitude = (0.015f + bump / 100f * 0.095f)
            val lobes = 12
            val path = Path()
            for (i in 0..720) {
                val a = 2.0 * PI * i / 720.0 - PI / 2.0
                val r = base * (1.0 + amplitude * cos(lobes * a))
                val x = cx + (r * cos(a)).toFloat()
                val y = cy + (r * sin(a)).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            val alpha = (opacity * 255 / 100).coerceIn(0,255)
            val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
            }
            canvas.drawPath(path, fill)
            val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 3f
                color = Color.argb((alpha * 0.65f).toInt(), 105, 105, 98)
            }
            canvas.drawPath(path, outline)
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = Color.argb(alpha, 65, 75, 61)
            }
            for (i in 0 until 12) {
                val a = 2.0 * PI * i / 12.0 - PI / 2.0
                val r = SIZE * 0.355
                canvas.drawCircle(cx + (r * cos(a)).toFloat(), cy + (r * sin(a)).toFloat(), SIZE * 0.008f, dotPaint)
            }
            return bitmap
        }

        private fun updatePendingIntent(context: Context): PendingIntent {
            val intent = Intent(context, PixelScallopWidgetProvider::class.java).setAction(ACTION_MINUTE)
            return PendingIntent.getBroadcast(
                context, 8102, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            )
        }

        private fun scheduleNextMinute(context: Context) {
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = updatePendingIntent(context)
            val now = System.currentTimeMillis()
            val next = (now / 60000L + 1L) * 60000L
            if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi)
            else alarm.setExact(AlarmManager.RTC, next, pi)
        }
    }
}
